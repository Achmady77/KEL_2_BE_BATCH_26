package com.juaracoding.situs;


/*
IntelliJ IDEA 2025.1.2 (Ultimate Edition)
Build #IU-251.26094.121, built on June 3, 2025
@Author lenovo Achmadi Suryo Utomo
Java Developer
Created on 14/08/2025 19:47
@Last Modified 14/08/2025 19:47
Version 1.0
*/

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class SitusApplication {
    public static void main(String[] args) {
        SpringApplication.run(SitusApplication.class, args);
    }

}
